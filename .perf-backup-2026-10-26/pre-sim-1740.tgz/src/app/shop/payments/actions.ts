"use server";
import { revalidatePath } from "next/cache";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
export type ActionState = { error?: string; success?: string };
export async function recordPayment(_p: ActionState, fd: FormData): Promise<ActionState> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !["shop_admin", "employee"].includes(s.profile.role)) return { error: "Not authorized" };
  const agreement_id = String(fd.get("agreement_id") || "").trim();
  const amount = Number(String(fd.get("amount") || "0") || 0);
  if (!agreement_id) return { error: "Select an agreement." };
  if (amount <= 0) return { error: "Amount must be greater than zero." };
  const supabase = createClient();
  const { data: agr, error: aErr } = await supabase.from("installment_agreements").select("outstanding_balance, customer_id").eq("id", agreement_id).single();
  if (aErr || !agr) return { error: "Agreement not found." };
  const { error: pErr } = await supabase.from("payment_transactions").insert({
    shop_id: s.profile.shop_id, agreement_id, customer_id: agr.customer_id, amount,
    method: (String(fd.get("method") || "cash")) as string, reference: String(fd.get("reference") || "").trim() || null,
    verification: "verified", recorded_by: s.user.id,
  });
  if (pErr) return { error: pErr.message };
  const newBalance = Math.max(Number(agr.outstanding_balance) - amount, 0);
  await supabase.from("installment_agreements").update({
    outstanding_balance: newBalance, ...(newBalance === 0 ? { status: "completed" } : {}),
  }).eq("id", agreement_id);
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: "record_payment", entity: "payment_transactions", entity_id: agreement_id, details: { amount, newBalance } });
  revalidatePath("/shop/payments"); revalidatePath("/shop/installments"); revalidatePath("/shop");
  revalidatePath("/employee/payments"); revalidatePath("/employee");
  return { success: `Payment of ${amount.toLocaleString()} recorded. New balance: ${newBalance.toLocaleString()}.` };
}
