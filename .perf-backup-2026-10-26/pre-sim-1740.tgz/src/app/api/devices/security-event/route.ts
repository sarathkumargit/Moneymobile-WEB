export const runtime = "nodejs";
import { createAdminClient } from "@/lib/supabase/admin";
import { sha256, resolveAgreementId } from "@/lib/device-api";

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b) return Response.json({ success: false, error: "bad request" }, { status: 400 });
  const admin = createAdminClient();
  const { data: enr } = await admin.from("device_enrollments").select("id,shop_id,device_id,customer_id,agreement_id,device_token_hash").eq("id", b.device_id).maybeSingle();
  if (!enr || enr.device_token_hash !== sha256(b.device_token || "")) return Response.json({ success: false, error: "unauthorized" }, { status: 401 });
  const type = String(b.event_type ?? "unknown");
  const isSim = type.toLowerCase().includes("sim");
  await admin.from("device_security_events").insert({
    shop_id: enr.shop_id, enrollment_id: enr.id, device_id: enr.device_id,
    event_type: type, details: b.details ?? null,
    status: isSim ? "approval_required" : "new",
  });

  // A SIM swap locks the phone server-side too, so it stays locked until staff review it.
  if (isSim) {
    const agreementId = await resolveAgreementId(admin, enr);
    if (agreementId) await admin.from("installment_agreements").update({ restriction: "restricted" }).eq("id", agreementId);
  }
  return Response.json({ success: true, data: null, message: "recorded" });
}
