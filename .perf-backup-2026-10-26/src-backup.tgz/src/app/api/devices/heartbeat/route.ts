export const runtime = "nodejs";
import { createAdminClient } from "@/lib/supabase/admin";
import { sha256, resolveAgreementId, buildAgreementStatus } from "@/lib/device-api";

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b) return Response.json({ success: false }, { status: 400 });
  const admin = createAdminClient();
  const { data: enr } = await admin.from("device_enrollments").select("*").eq("id", b.device_id).maybeSingle();
  if (!enr || !enr.device_token_hash || enr.device_token_hash !== sha256(b.device_token || "")) {
    return Response.json({ success: false }, { status: 401 });
  }
  // SIM-change detection (backup to the phone's own instant lock): flag it and lock server-side.
  if (enr.sim_iccid && b.sim_iccid && b.sim_iccid !== enr.sim_iccid) {
    await admin.from("device_security_events").insert({
      shop_id: enr.shop_id, enrollment_id: enr.id, device_id: enr.device_id,
      event_type: "sim_change", details: `SIM changed: ${enr.sim_iccid} → ${b.sim_iccid}`, status: "approval_required",
    });
    const simAgr = await resolveAgreementId(admin, enr);
    if (simAgr) await admin.from("installment_agreements").update({ restriction: "restricted" }).eq("id", simAgr);
  }
  const now = new Date().toISOString();
  const base = {
    last_sync: now, sim_iccid: b.sim_iccid ?? enr.sim_iccid, sim_operator: b.sim_operator ?? enr.sim_operator,
    battery_level: b.battery_level ?? null, network_type: b.network_type ?? null, updated_at: now,
  };
  const { error: updErr } = await admin.from("device_enrollments")
    .update({ ...base, management_active: b.device_owner === true, management_checked_at: now })
    .eq("id", enr.id);
  if (updErr) {
    // Until migration 0005 is applied the management_* columns don't exist and PostgREST rejects
    // the whole update — last_sync never moved, so the dashboard showed the phone as not connected.
    console.error("[heartbeat] update failed, retrying without management columns (run migration 0005_management_status.sql):", updErr.message);
    const { error: retryErr } = await admin.from("device_enrollments").update(base).eq("id", enr.id);
    if (retryErr) console.error("[heartbeat] update failed:", retryErr.message);
  }

  // Deliver the NEWEST pending command; older pending ones are stale (e.g. repeated Lock clicks).
  // Location (best-effort, isolated: if migration 0011 hasn't run yet this just logs and skips).
  const lat = typeof b.latitude === "number" ? b.latitude : null;
  const lng = typeof b.longitude === "number" ? b.longitude : null;
  const acc = typeof b.location_accuracy === "number" ? Math.round(b.location_accuracy) : null;
  if (lat !== null && lng !== null) {
    const { error: locErr } = await admin.from("device_enrollments")
      .update({ last_lat: lat, last_lng: lng, location_accuracy: acc, location_at: now }).eq("id", enr.id);
    if (locErr) {
      console.error("[heartbeat] location update failed (run migration 0011_device_location.sql):", locErr.message);
    } else if (!enr.location_at || Date.now() - new Date(enr.location_at).getTime() > 10 * 60 * 1000) {
      // Keep the history trail bounded: at most one point per ~10 minutes.
      const { error: histErr } = await admin.from("device_locations").insert({ shop_id: enr.shop_id, enrollment_id: enr.id, device_id: enr.device_id, lat, lng, accuracy: acc, recorded_at: now });
      if (histErr) console.error("[heartbeat] location history insert failed:", histErr.message);
    }
  }

  const { data: cmd } = await admin.from("device_commands").select("*").eq("enrollment_id", enr.id).eq("status", "pending").order("created_at", { ascending: false }).limit(1).maybeSingle();
  let command = null;
  if (cmd) {
    await admin.from("device_commands").update({ status: "superseded", result: "replaced by a newer command" })
      .eq("enrollment_id", enr.id).eq("status", "pending").neq("id", cmd.id);
    await admin.from("device_commands").update({ status: "sent", sent_at: new Date().toISOString() }).eq("id", cmd.id);
    command = { id: cmd.id, type: cmd.command, reason: cmd.reason, issued_at: cmd.created_at };
  }
  const agreementId = await resolveAgreementId(admin, enr);
  // Persist the resolved link so it is permanent even if enrolled without one
  if (agreementId && agreementId !== enr.agreement_id) {
    await admin.from("device_enrollments").update({ agreement_id: agreementId }).eq("id", enr.id);
  }
  const agreement = await buildAgreementStatus(admin, agreementId);
  return Response.json({ success: true, command, agreement });
}
