import "server-only";
import { createAdminClient } from "@/lib/supabase/admin";

const BUCKET = "customer-docs";
const MAX_BYTES = 10 * 1024 * 1024; // 10 MB

// Uploads an ID-card image to the private bucket and returns its storage path (or null).
// Never throws — a failed/absent upload just means no document is stored.
export async function uploadDoc(file: FormDataEntryValue | null, folder: string): Promise<string | null> {
  if (!file || typeof file === "string") return null;
  const f = file as File;
  if (!f.size) return null;
  if (!f.type.startsWith("image/")) return null;
  if (f.size > MAX_BYTES) return null;
  try {
    const ext = (f.name.split(".").pop() || "jpg").toLowerCase().replace(/[^a-z0-9]/g, "") || "jpg";
    const path = `${folder}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
    const buf = Buffer.from(await f.arrayBuffer());
    const admin = createAdminClient();
    const { error } = await admin.storage.from(BUCKET).upload(path, buf, { contentType: f.type, upsert: false });
    if (error) { console.error("[storage] upload failed:", error.message); return null; }
    return path;
  } catch (e) {
    console.error("[storage] upload exception:", e);
    return null;
  }
}

// Short-lived signed URL for viewing a stored doc (bucket is private).
export async function signedDocUrl(path: string | null | undefined): Promise<string | null> {
  if (!path) return null;
  try {
    const admin = createAdminClient();
    const { data } = await admin.storage.from(BUCKET).createSignedUrl(path, 3600);
    return data?.signedUrl ?? null;
  } catch { return null; }
}
