import { cache } from "react";
import { createClient } from "@/lib/supabase/server";
import type { Role } from "@/lib/nav";

export type Profile = {
  id: string;
  full_name: string | null;
  username: string | null;
  role: Role;
  shop_id: string | null;
  status: string;
};

// Returns the signed-in user + their profile, or null if not authenticated.
//
// Performance: the middleware (src/lib/supabase/middleware.ts) already calls the
// authoritative, network-backed auth.getUser() on every request and refreshes the
// session cookie. So here we read that already-validated session locally with
// getSession() (no network round-trip) instead of calling getUser() again — this
// removes a ~round-trip-to-Supabase of latency from every page and every server action.
//
// Wrapped in React cache() so that multiple server components / calls within a single
// request share one result (one profile query per request, not one per caller).
export const getSessionProfile = cache(async () => {
  const supabase = createClient();
  const {
    data: { session },
  } = await supabase.auth.getSession();
  const user = session?.user;
  if (!user) return null;

  const { data: profile } = await supabase
    .from("profiles")
    .select("id, full_name, username, role, shop_id, status")
    .eq("id", user.id)
    .single();

  if (!profile) return null;
  return { user, profile: profile as Profile };
});

export function dashboardPath(role?: string | null) {
  switch (role) {
    case "super_admin":
      return "/super-admin";
    case "shop_admin":
      return "/shop";
    default:
      return "/employee";
  }
}
