"use server";
import { revalidatePath } from "next/cache";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { setFlash } from "@/lib/flash";
import { sha256, newToken, resolveAgreementId } from "@/lib/device-api";
export type ActionState = { error?: string; success?: string; at?: number };

const canOperate = (role: string) => role === "shop_admin" || role === "employee";

export async function generateEnrollmentToken(_p: ActionState, fd: FormData): Promise<ActionState> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return { error: "Not authorized" };
  const device_id = String(fd.get("device_id") || "").trim();
  const agreement_id = String(fd.get("agreement_id") || "").trim() || null;
  if (!device_id) return { error: "Select a device." };
  const supabase = createClient();
  const { data: dev } = await supabase.from("devices").select("customer_id").eq("id", device_id).single();
  const plain = newToken().slice(0, 12).toUpperCase();
  // one enrollment row per device — reuse it so tokens + commands stay on the same record
  const { data: existing } = await supabase.from("device_enrollments").select("id").eq("device_id", device_id).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (existing) {
    await supabase.from("device_enrollments").update({ enroll_token_hash: sha256(plain), status: "pending", agreement_id, customer_id: dev?.customer_id ?? null, updated_at: new Date().toISOString() }).eq("id", existing.id);
  } else {
    const { error } = await supabase.from("device_enrollments").insert({ shop_id: s.profile.shop_id, device_id, agreement_id, customer_id: dev?.customer_id ?? null, enroll_token_hash: sha256(plain), status: "pending", created_by: s.user.id });
    if (error) return { error: error.message };
  }
  revalidatePath("/shop/device-management");
  return { success: `Enrollment token: ${plain} — enter this in the app during enrollment. Works once.` };
}

type Supa = ReturnType<typeof createClient>;
type Session = NonNullable<Awaited<ReturnType<typeof getSessionProfile>>>;
type EnrRef = { id: string; agreement_id: string | null; device_id: string | null; customer_id: string | null };

async function getOrCreateEnrollment(supabase: Supa, s: Session, device_id: string): Promise<EnrRef | null> {
  const { data: existing } = await supabase.from("device_enrollments").select("id,agreement_id,device_id,customer_id").eq("device_id", device_id).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (existing) return existing as EnrRef;
  const { data: dev } = await supabase.from("devices").select("customer_id").eq("id", device_id).single();
  const { data: created } = await supabase.from("device_enrollments").insert({ shop_id: s.profile.shop_id, device_id, customer_id: dev?.customer_id ?? null, agreement_id: null, enroll_token_hash: sha256(newToken()), status: "pending", created_by: s.user.id }).select("id,agreement_id,device_id,customer_id").single();
  return (created as EnrRef) ?? null;
}

// Queues a command AND flips the agreement's restriction flag.
// The agreement is resolved exactly like the heartbeat does (resolveAgreementId), so the
// flag we set is the one the phone reads back. If they differ, the phone locks on the
// command and then the next heartbeat (locked:false) immediately unlocks it again.
async function queueCommand(supabase: Supa, s: Session, enr: EnrRef, command: string, device_id: string | null): Promise<ActionState> {
  // Only the newest instruction matters: retire anything still waiting so repeated clicks
  // don't build a backlog the phone has to work through one check-in at a time.
  await supabase.from("device_commands").update({ status: "superseded", result: "replaced by a newer command" }).eq("enrollment_id", enr.id).eq("status", "pending");
  const { error } = await supabase.from("device_commands").insert({ shop_id: s.profile.shop_id, enrollment_id: enr.id, device_id: device_id ?? enr.device_id, command, status: "pending", issued_by: s.user.id });
  if (error) return { error: `Could not queue command: ${error.message}`, at: Date.now() };

  const agreementId = await resolveAgreementId(supabase as unknown as Parameters<typeof resolveAgreementId>[0], enr);
  const restriction = command === "LOCK_DEVICE" ? "restricted" : command === "UNLOCK_DEVICE" ? "active" : null;
  if (agreementId && restriction) {
    const { error: rErr } = await supabase.from("installment_agreements").update({ restriction }).eq("id", agreementId);
    if (rErr) return { error: `Command queued, but the agreement could not be updated: ${rErr.message}`, at: Date.now() };
    if (agreementId !== enr.agreement_id) await supabase.from("device_enrollments").update({ agreement_id: agreementId }).eq("id", enr.id);
  }
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: "device_command", entity: "device_commands", entity_id: device_id ?? enr.id, details: { command } });

  const label = command === "LOCK_DEVICE" ? "Lock" : command === "UNLOCK_DEVICE" ? "Unlock" : command;
  return { success: `${label} command queued. The phone applies it on its next check-in (about a minute while it is online).`, at: Date.now() };
}

// Device-centric command used by the customer page (works before the phone connects — the command queues)
export async function deviceCommand(_p: ActionState, fd: FormData): Promise<ActionState> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return { error: "Not authorized", at: Date.now() };
  const device_id = String(fd.get("device_id") || "").trim();
  const command = String(fd.get("command") || "").trim();
  const customer_id = String(fd.get("customer_id") || "").trim() || null;
  if (!device_id || !command) return { error: "Missing device or command.", at: Date.now() };
  const supabase = createClient();
  const { data: rel } = await supabase.from("device_enrollments").select("status").eq("device_id", device_id).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (rel?.status === "released") return { error: "This phone has been released to the customer — the shop no longer controls it.", at: Date.now() };
  const enr = await getOrCreateEnrollment(supabase, s, device_id);
  if (!enr) return { error: "Could not find or create an enrollment for this phone.", at: Date.now() };
  const result = await queueCommand(supabase, s, enr, command, device_id);
  if (customer_id) { revalidatePath(`/shop/customers/${customer_id}`); revalidatePath(`/employee/customers/${customer_id}`); }
  revalidatePath("/shop/device-management");
  return result;
}

// Final hand-over once the phone is fully paid. Queues RELEASE_DEVICE: the phone removes every
// restriction, gives up Device Owner (uninstall + factory reset work again) and stops checking in.
// When the phone confirms, /api/devices/command-ack marks the enrollment "released" and revokes its token.
export async function releaseDevice(_p: ActionState, fd: FormData): Promise<ActionState> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return { error: "Not authorized", at: Date.now() };
  const device_id = String(fd.get("device_id") || "").trim();
  const customer_id = String(fd.get("customer_id") || "").trim() || null;
  if (!device_id) return { error: "Missing device.", at: Date.now() };
  const supabase = createClient();

  const { data: row } = await supabase.from("device_enrollments").select("id,agreement_id,device_id,customer_id,status").eq("device_id", device_id).order("created_at", { ascending: false }).limit(1).maybeSingle();
  if (!row) return { error: "This phone was never enrolled, so there is nothing to release.", at: Date.now() };
  if (row.status === "released") return { error: "This phone is already released.", at: Date.now() };
  const enr = row as EnrRef;

  // Only a fully paid phone can be released: every live agreement on this phone must be at Rs 0.
  const agreementId = await resolveAgreementId(supabase as unknown as Parameters<typeof resolveAgreementId>[0], enr);
  const { data: agrs, error: aErr } = await supabase.from("installment_agreements").select("id,outstanding_balance,status")
    .or(agreementId ? `device_id.eq.${device_id},id.eq.${agreementId}` : `device_id.eq.${device_id}`);
  if (aErr) return { error: `Could not check the balance: ${aErr.message}`, at: Date.now() };
  const live = (agrs ?? []).filter((a: { status: string }) => !["cancelled", "released"].includes(a.status));
  const owing = live.reduce((sum: number, a: { outstanding_balance: number | null }) => sum + Math.max(0, Number(a.outstanding_balance || 0)), 0);
  if (owing > 0) return { error: `Can't release yet — Rs ${owing.toLocaleString()} is still outstanding on this phone.`, at: Date.now() };

  await supabase.from("device_commands").update({ status: "superseded", result: "replaced by release" }).eq("enrollment_id", enr.id).eq("status", "pending");
  const { error } = await supabase.from("device_commands").insert({ shop_id: s.profile.shop_id, enrollment_id: enr.id, device_id, command: "RELEASE_DEVICE", reason: "Fully paid", status: "pending", issued_by: s.user.id });
  if (error) return { error: `Could not queue release: ${error.message}`, at: Date.now() };

  // Make sure the phone isn't left locked while the release is in flight. The "released" status
  // on the enrollment, device and agreements is set only once the phone CONFIRMS (in command-ack),
  // so a failed release never leaves the dashboard thinking the phone was handed over.
  const ids = live.map((a: { id: string }) => a.id);
  if (ids.length) await supabase.from("installment_agreements").update({ restriction: "active" }).in("id", ids);
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: "device_release_requested", entity: "device_enrollments", entity_id: enr.id, details: { device_id } });

  if (customer_id) { revalidatePath(`/shop/customers/${customer_id}`); revalidatePath(`/employee/customers/${customer_id}`); }
  revalidatePath("/shop/device-management");
  return { success: "Release queued. On its next check-in the phone removes all restrictions and MoneyMobile stops managing it.", at: Date.now() };
}

// Repossess / prepare a phone for resale. Clears its history, location and links so the SAME
// IMEI comes back as a fresh device, and marks it released (unmanaged) + back in stock.
// Does NOT require the balance to be zero — this is a shop decision when pulling a phone back.
export async function resetDeviceRecord(fd: FormData): Promise<void> {
  const s = await getSessionProfile();
  if (!s || s.profile.role !== "shop_admin" || !s.profile.shop_id) return;
  const device_id = String(fd.get("device_id") || "").trim();
  const customer_id = String(fd.get("customer_id") || "").trim() || null;
  if (!device_id) return;
  const supabase = createClient();
  const { data: enrs } = await supabase.from("device_enrollments").select("id").eq("device_id", device_id);
  const ids = (enrs ?? []).map((e: { id: string }) => e.id);
  if (ids.length) {
    await supabase.from("device_commands").delete().in("enrollment_id", ids);
    await supabase.from("device_security_events").delete().in("enrollment_id", ids);
    await supabase.from("device_locations").delete().in("enrollment_id", ids);
    await supabase.from("device_enrollments").update({
      status: "released", device_token_hash: null, management_active: false, agreement_id: null,
      last_lat: null, last_lng: null, location_accuracy: null, location_at: null, updated_at: new Date().toISOString(),
    }).in("id", ids);
  }
  await supabase.from("devices").update({ status: "in_stock" }).eq("id", device_id);
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: "reset_device_for_resale", entity: "devices", entity_id: device_id, details: {} });
  setFlash("Phone reset for resale — history cleared. Factory reset it, then run setup again.");
  if (customer_id) { revalidatePath(`/shop/customers/${customer_id}`); revalidatePath(`/employee/customers/${customer_id}`); }
  revalidatePath("/shop/device-management");
}

// kept for the Device Mgmt page (enrollment-based)
export async function issueCommand(fd: FormData): Promise<void> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return;
  const enrollment_id = String(fd.get("enrollment_id") || "").trim();
  const command = String(fd.get("command") || "").trim();
  const device_id = String(fd.get("device_id") || "").trim() || null;
  const agreement_id = String(fd.get("agreement_id") || "").trim() || null;
  if (!enrollment_id || !command) return;
  const supabase = createClient();
  const { data: row } = await supabase.from("device_enrollments").select("id,agreement_id,device_id,customer_id").eq("id", enrollment_id).maybeSingle();
  const enr: EnrRef = (row as EnrRef) ?? { id: enrollment_id, agreement_id, device_id, customer_id: null };
  await queueCommand(supabase, s, enr, command, device_id);
  revalidatePath("/shop/device-management");
}

export async function resolveSecurityEvent(fd: FormData): Promise<void> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return;
  const event_id = String(fd.get("event_id") || "").trim();
  const decision = String(fd.get("decision") || "").trim();
  const customer_id = String(fd.get("customer_id") || "").trim() || null;
  if (!event_id) return;
  const supabase = createClient();
  const approved = decision === "approved";
  await supabase.from("device_security_events").update({ status: approved ? "approved" : "rejected", resolved_by: s.user.id, resolved_at: new Date().toISOString() }).eq("id", event_id);
  if (approved) {
    // Approving the SIM event is the staff decision to let the customer use the phone: unlock it
    // (queue UNLOCK + clear the restriction, same as the Unlock button). Rejecting keeps it locked.
    const { data: ev } = await supabase.from("device_security_events").select("enrollment_id").eq("id", event_id).maybeSingle();
    const { data: enr } = ev?.enrollment_id
      ? await supabase.from("device_enrollments").select("id,agreement_id,device_id,customer_id").eq("id", ev.enrollment_id).maybeSingle()
      : { data: null };
    if (enr) await queueCommand(supabase, s, enr as EnrRef, "UNLOCK_DEVICE", (enr as EnrRef).device_id);
  }
  setFlash(approved ? "SIM approved — unlock sent to the phone." : "SIM rejected — the phone stays locked.");
  if (customer_id) { revalidatePath(`/shop/customers/${customer_id}`); revalidatePath(`/employee/customers/${customer_id}`); }
  revalidatePath("/shop/device-management");
}
