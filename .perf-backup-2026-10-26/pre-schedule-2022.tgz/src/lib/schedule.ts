import "server-only";
import type { SupabaseClient } from "@supabase/supabase-js";

// Monthly installment schedule: payment allocation + automatic lock on overdue.
type Db = SupabaseClient;

/** Today's date (YYYY-MM-DD) in this server's local time zone — the shop's calendar day. */
export function localToday(d = new Date()): string {
  const off = d.getTimezoneOffset() * 60000;
  return new Date(d.getTime() - off).toISOString().slice(0, 10);
}
function addDays(ymd: string, n: number): string {
  const d = new Date(ymd + "T00:00:00Z"); d.setUTCDate(d.getUTCDate() + n); return d.toISOString().slice(0, 10);
}
const round2 = (n: number) => Math.round(n * 100) / 100;

type Row = { id: string; seq: number; due_date: string; amount: number; paid: number; status: string };

/**
 * Applies a payment to the schedule: the chosen month first (if any), then the oldest unpaid
 * months. Updates paid / status (partial or paid) per month.
 */
export async function allocateToSchedule(db: Db, agreementId: string, amount: number, preferId?: string | null) {
  const { data } = await db.from("installment_schedules").select("id,seq,due_date,amount,paid,status")
    .eq("agreement_id", agreementId).neq("status", "paid").order("due_date", { ascending: true });
  const rows = ((data ?? []) as Row[]).sort((a, b) => (a.id === preferId ? -1 : b.id === preferId ? 1 : 0));
  let left = round2(amount);
  for (const r of rows) {
    if (left <= 0) break;
    const due = round2(Number(r.amount) - Number(r.paid || 0));
    if (due <= 0) continue;
    const take = Math.min(due, left);
    const paid = round2(Number(r.paid || 0) + take);
    const full = paid >= Number(r.amount) - 0.005;
    const patch: Record<string, unknown> = { paid, status: full ? "paid" : "partial" };
    const { error } = await db.from("installment_schedules").update(full ? { ...patch, paid_at: new Date().toISOString() } : patch).eq("id", r.id);
    if
