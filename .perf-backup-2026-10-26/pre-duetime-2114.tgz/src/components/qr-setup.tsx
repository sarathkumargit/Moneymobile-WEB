"use client";
import { useEffect, useMemo, useState } from "react";
import { QrCode, AlertCircle, Wifi, Eye, EyeOff } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Android Enterprise QR provisioning: a new or factory-reset phone scans this QR on its welcome
// screen, downloads MoneyMobile from this server, makes it the device manager and registers
// itself to the shop (details travel in the admin-extras bundle). No computer or cable needed.

type Config = {
  shopId: string; secret: string; serverUrl: string; apkUrl: string; fromLocalhost: boolean;
  apk: { size: number; built: string; checksum: string } | null;
};

export function QrSetup() {
  const [cfg, setCfg] = useState<Config | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [qrSvg, setQrSvg] = useState<((t: string) => string) | null>(null);
  const [ssid, setSsid] = useState("");
  const [password, setPassword] = useState("");
  const [security, setSecurity] = useState<"WPA" | "WEP" | "NONE">("WPA");
  const [shown, setShown] = useState(false);
  const [showPw, setShowPw] = useState(false);

  useEffect(() => {
    fetch("/api/setup-kit/config", { cache: "no-store" })
      .then(async (r) => { const j = await r.json(); if (!r.ok) throw new Error(j.error || r.statusText); setCfg(j); })
      .catch((e) => setError(String(e.message ?? e)));
    import(/* webpackIgnore: true */ "/vendor/mm-toolkit.js" as string)
      .then((m: { qrSvg: (t: string, c?: number) => string }) => setQrSvg(() => (t: string) => m.qrSvg(t, 4)))
      .catch(() => setError("Could not load the QR generator (public/vendor/mm-toolkit.js)."));
  }, []);

  const payload = useMemo(() => {
    if (!cfg?.apk) return null;
    const p: Record<string, unknown> = {
      "android.app.extra.PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME": "com.moneymobile.installment/.admin.DeviceAdminReceiver",
      "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_DOWNLOAD_LOCATION": cfg.apkUrl,
      "android.app.extra.PROVISIONING_DEVICE_ADMIN_PACKAGE_CHECKSUM": cfg.apk.checksum,
      "android.app.extra.PROVISIONING_LEAVE_ALL_SYSTEM_APPS_ENABLED": true,
      "android.app.extra.PROVISIONING_SKIP_ENCRYPTION": true,
      "android.app.extra.PROVISIONING_ADMIN_EXTRAS_BUNDLE": {
        shop_id: cfg.shopId,
        enroll_secret: cfg.secret,
        server_url: cfg.serverUrl,
      },
    };
    if (ssid.trim()) {
      p["android.app.extra.PROVISIONING_WIFI_SSID"] = ssid.trim();
      p["android.app.extra.PROVISIONING_WIFI_SECURITY_TYPE"] = security;
      if (security !== "NONE") p["android.app.extra.PROVISIONING_WIFI_PASSWORD"] = password;
    }
    return JSON.stringify(p);
  }, [cfg, ssid, password, security]);

  const svg = shown && payload && qrSvg ? qrSvg(payload) : null;

  return (
    <Card>
      <CardHeader><CardTitle className="flex items-center gap-2"><QrCode className="h-5 w-5" /> Set up by QR code (no computer)</CardTitle></CardHeader>
      <CardContent className="space-y-5">
        <p className="text-sm text-muted-foreground">
          For a <b>new or factory-reset</b> phone. It scans this code on its welcome screen, downloads MoneyMobile from this website,
          turns on full management and registers itself to your shop. If QR setup doesn&apos;t work on a phone, use the setup file above instead.
        </p>

        {error && <Warn>{error}</Warn>}
        {cfg && !cfg.apk && <Warn>The app file is missing on the server. Run <code>Money mobile/publish-app.command</code> first.</Warn>}
        {cfg?.fromLocalhost && (
          <p className="rounded-lg border bg-muted/30 px-3 py-2 text-xs text-muted-foreground">
            The phone will download the app from <code>{cfg.apkUrl}</code> (this computer&apos;s Wi-Fi address). Keep this website running and the phone on the same Wi-Fi.
          </p>
        )}

        <div className="grid gap-4 md:grid-cols-[1fr_auto]">
          <div className="space-y-3">
            <p className="flex items-center gap-2 text-sm font-medium"><Wifi className="h-4 w-4" /> Shop Wi-Fi (recommended — the phone joins it automatically)</p>
            <div className="grid gap-3 sm:grid-cols-2">
              <div className="space-y-1"><Label htmlFor="qr-ssid">Network name</Label><Input id="qr-ssid" value={ssid} onChange={(e) => { setSsid(e.target.value); setShown(false); }} placeholder="Shop Wi-Fi name" autoComplete="off" /></div>
              <div className="space-y-1">
                <Label htmlFor="qr-sec">Security</Label>
                <select id="qr-sec" value={security} onChange={(e) => { setSecurity(e.target.value as typeof security); setShown(false); }} className="h-10 w-full rounded-md border border-input bg-card px-3 text-sm">
                  <option value="WPA">WPA / WPA2 / WPA3</option><option value="WEP">WEP</option><option value="NONE">Open (no password)</option>
                </select>
              </div>
              {security !== "NONE" && (
                <div className="space-y-1 sm:col-span-2">
                  <Label htmlFor="qr-pw">Password</Label>
                  <div className="flex gap-2">
                    <Input id="qr-pw" type={showPw ? "text" : "password"} value={password} onChange={(e) => { setPassword(e.target.value); setShown(false); }} autoComplete="off" />
                    <Button type="button" variant="outline" size="sm" onClick={() => setShowPw((v) => !v)}>{showPw ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}</Button>
                  </div>
                </div>
              )}
            </div>
            <p className="text-xs text-muted-foreground">The Wi-Fi details stay in this browser — they are only put inside the QR code.</p>
            <Button type="button" onClick={() => setShown(true)} disabled={!payload || !qrSvg}><QrCode className="h-4 w-4" /> {shown ? "QR code shown" : "Show QR code"}</Button>
          </div>

          <div className="flex min-h-[280px] min-w-[280px] items-center justify-center rounded-xl border bg-white p-3">
            {svg ? <div className="h-[300px] w-[300px]" dangerouslySetInnerHTML={{ __html: svg }} />
              : <p className="max-w-[220px] text-center text-xs text-slate-500">Enter the shop Wi-Fi (optional) and click <b>Show QR code</b>.</p>}
          </div>
        </div>

        <ol className="list-decimal space-y-1.5 pl-5 text-sm">
          <li>Use a <b>new or factory-reset</b> phone and insert the customer&apos;s SIM.</li>
          <li>On the first <b>Welcome / Hi there</b> screen, <b>tap the same empty spot 6 times</b>. A QR scanner opens.</li>
          <li>Scan this code. If asked, connect to Wi-Fi and accept the &quot;managed device&quot; notice.</li>
          <li>The phone downloads MoneyMobile and finishes setup by itself. Within a minute it appears under <b>Devices</b> by its IMEI.</li>
        </ol>
        <p className="text-xs text-amber-700 dark:text-amber-400">This QR code contains your shop&apos;s setup secret. Don&apos;t photograph or share it outside the shop.</p>
      </CardContent>
    </Card>
  );
}

function Warn({ children }: { children: React.ReactNode }) {
  return <div className="flex items-start gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-800 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300"><AlertCircle className="mt-0.5 h-4 w-4 shrink-0" /><div>{children}</div></div>;
}
