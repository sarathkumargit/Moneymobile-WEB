import { promises as fs } from "fs";
import path from "path";
import { Apple, Download, MonitorSmartphone, Smartphone, Usb, Wifi, ShieldAlert } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { QrSetup } from "@/components/qr-setup";

// "Install App" page for shop admins and employees: one-click setup kits for Windows and macOS.
// Each kit is generated for the signed-in user's shop (see /api/setup-kit/[os]).
export async function InstallApp() {
  let built: string | null = null;
  try {
    const st = await fs.stat(path.join(process.cwd(), "setup-kit", "MoneyMobile.apk"));
    built = st.mtime.toLocaleString();
  } catch { /* kit missing — the download route explains */ }

  const Kit = ({ os, title, icon: Icon, file, run }: { os: "windows" | "mac"; title: string; icon: typeof Apple; file: string; run: string }) => (
    <Card className="flex flex-col">
      <CardHeader><CardTitle className="flex items-center gap-2"><Icon className="h-5 w-5" /> {title}</CardTitle></CardHeader>
      <CardContent className="flex flex-1 flex-col gap-4">
        <p className="text-sm text-muted-foreground">Contains the MoneyMobile app, the setup file <code>{file}</code> and your shop&apos;s settings. Nothing to edit.</p>
        <a href={`/api/setup-kit/${os}`} download className="inline-flex h-11 items-center justify-center gap-2 rounded-lg bg-primary px-5 text-sm font-semibold text-primary-foreground shadow-sm hover:opacity-90">
          <Download className="h-4 w-4" /> Download for {title}
        </a>
        <p className="text-xs text-muted-foreground">{run}</p>
      </CardContent>
    </Card>
  );

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Install the MoneyMobile app on a phone</h2>
        <p className="text-sm text-muted-foreground">Download the setup kit for the computer you&apos;re using, unzip it, plug in the phone and run one file. The phone is installed, locked-down and registered to your shop automatically.{built ? ` App build: ${built}.` : ""}</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        <Kit os="windows" title="Windows" icon={MonitorSmartphone} file="setup-windows.bat" run={'Run: double-click setup-windows.bat. If "Windows protected your PC" appears, click More info → Run anyway.'} />
        <Kit os="mac" title="macOS" icon={Apple} file="setup-mac.command" run="Run: right-click setup-mac.command → Open → Open (first time only; after that, double-click)." />
      </div>

      <QrSetup />

      <Card>
        <CardHeader><CardTitle className="flex items-center gap-2"><Smartphone className="h-4 w-4" /> Steps for each phone (setup file)</CardTitle></CardHeader>
        <CardContent>
          <ol className="list-decimal space-y-2 pl-5 text-sm">
            <li><b>Turn on USB debugging:</b> Settings → About phone → tap <i>Build number</i> 7 times, then Settings → System → Developer options → <i>USB debugging</i> ON.</li>
            <li><b>Remove accounts:</b> Settings → Passwords &amp; accounts → remove Google / Samsung accounts (WhatsApp can stay).</li>
            <li><b>Insert the customer&apos;s SIM</b> and connect the phone to the shop Wi-Fi. This SIM becomes the approved one — removing or changing it later locks the phone.</li>
            <li><span className="inline-flex items-center gap-1"><Usb className="h-3.5 w-3.5" /> <b>Plug the phone into the computer</b></span> and tap <i>Allow</i> on the phone.</li>
            <li><b>Run the setup file</b> and wait for <b>DONE</b>. The phone then appears under Devices by its IMEI — assign it when creating the customer&apos;s agreement.</li>
          </ol>
        </CardContent>
      </Card>

      <div className="grid gap-4 md:grid-cols-2">
        <div className="flex gap-3 rounded-lg border bg-muted/30 p-4 text-sm">
          <Wifi className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
          <p className="text-muted-foreground">The phone talks to this website over the network. Run the setup on the computer that runs MoneyMobile (or open this site by its network address) so the phone gets the right server address.</p>
        </div>
        <div className="flex gap-3 rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900 dark:bg-amber-950/40 dark:text-amber-300">
          <ShieldAlert className="mt-0.5 h-4 w-4 shrink-0" />
          <p>The kit contains your shop&apos;s setup secret. Anyone with it can register phones to your shop — don&apos;t share it outside the shop.</p>
        </div>
      </div>
    </div>
  );
}
