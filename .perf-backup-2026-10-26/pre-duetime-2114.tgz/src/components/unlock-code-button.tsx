"use client";
import { useFormState, useFormStatus } from "react-dom";
import { KeyRound, CheckCircle2, AlertCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { generateUnlockKey, type ActionState } from "@/app/shop/unlocks/actions";
const initial: ActionState = {};
function Sub() { const { pending } = useFormStatus(); return <Button type="submit" size="sm" variant="outline" disabled={pending}><KeyRound className="h-3.5 w-3.5" /> {pending ? "…" : "30-min unlock code"}</Button>; }
export function UnlockCodeButton({ deviceId }: { deviceId: string }) {
  const [state, action] = useFormState(generateUnlockKey, initial);
  return (
    <div className="space-y-2">
      <form action={action}><input type="hidden" name="device_id" value={deviceId} /><Sub /></form>
      {state.success && <div className="flex items-center gap-2 rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm font-medium text-emerald-700"><CheckCircle2 className="h-4 w-4 shrink-0" />{state.success}</div>}
      {state.error && <div className="flex items-center gap-2 rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700"><AlertCircle className="h-4 w-4 shrink-0" />{state.error}</div>}
    </div>
  );
}
