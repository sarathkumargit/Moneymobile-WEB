"use server";
import { createHash, randomInt } from "crypto";
import { revalidatePath } from "next/cache";
import { getSessionProfile } from "@/lib/auth";
import { createClient } from "@/lib/supabase/server";
import { resolveAgreementId } from "@/lib/device-api";
export type ActionState = { error?: string; success?: string };

const canOperate = (role: string) => role === "shop_admin" || role === "employee";

// Approve a customer's unlock request: queue UNLOCK_DEVICE to the phone (applied on next check-in)
// and clear the agreement restriction, exactly like the dashboard Unlock button.
export async function resolveUnlockRequest(fd: FormData): Promise<void> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !canOperate(s.profile.role)) return;
  const request_id = String(fd.get("request_id") || "").trim();
  const decision = String(fd.get("decision") || "").trim();
  if (!request_id) return;
  const supabase = createClient();
  const { data: reqRow } = await supabase.from("device_unlock_requests").select("id,enrollment_id,device_id,agreement_id,status").eq("id", request_id).maybeSingle();
  if (!reqRow || reqRow.status !== "pending") return;

  if (decision === "approved" && reqRow.enrollment_id) {
    await supabase.from("device_commands").update({ status: "superseded", result: "replaced by unlock approval" }).eq("enrollment_id", reqRow.enrollment_id).eq("status", "pending");
    await supabase.from("device_commands").insert({ shop_id: s.profile.shop_id, enrollment_id: reqRow.enrollment_id, device_id: reqRow.device_id, command: "UNLOCK_DEVICE", reason: "Customer request approved", status: "pending", issued_by: s.user.id });
    const agreementId = reqRow.agreement_id ?? await resolveAgreementId(supabase as unknown as Parameters<typeof resolveAgreementId>[0], reqRow);
    if (agreementId) await supabase.from("installment_agreements").update({ restriction: "active" }).eq("id", agreementId);
  }

  await supabase.from("device_unlock_requests").update({ status: decision === "approved" ? "approved" : "rejected", resolved_by: s.user.id, resolved_at: new Date().toISOString() }).eq("id", request_id);
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: `unlock_request_${decision}`, entity: "device_unlock_requests", entity_id: request_id, details: {} });
  revalidatePath("/shop/unlocks");
  revalidatePath("/employee/unlocks");
}
export async function generateUnlockKey(_p: ActionState, fd: FormData): Promise<ActionState> {
  const s = await getSessionProfile();
  if (!s || !s.profile.shop_id || !["shop_admin","employee"].includes(s.profile.role)) return { error: "Not authorized" };
  const device_id = String(fd.get("device_id") || "").trim() || null;
  const agreement_id = String(fd.get("agreement_id") || "").trim() || null;
  if (!device_id && !agreement_id) return { error: "Select a device or an agreement." };
  // 6-digit key; store only its hash. 30-minute validity.
  const key = String(randomInt(100000, 999999));
  const key_hash = createHash("sha256").update(key).digest("hex");
  const expires_at = new Date(Date.now() + 30 * 60 * 1000).toISOString();
  const supabase = createClient();
  const { error } = await supabase.from("temporary_unlock_keys").insert({
    shop_id: s.profile.shop_id, device_id, agreement_id, key_hash, status: "unused", expires_at, created_by: s.user.id,
  });
  if (error) return { error: error.message };
  await supabase.from("audit_logs").insert({ shop_id: s.profile.shop_id, actor_id: s.user.id, action: "generate_unlock_key", entity: "temporary_unlock_keys", entity_id: device_id, details: { expires_at } });
  revalidatePath("/shop/unlocks");
  return { success: `Unlock key: ${key} — valid 30 minutes. Share it with the customer now (it won't be shown again).` };
}
