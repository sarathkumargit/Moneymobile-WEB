export const runtime = "nodejs";
import { createAdminClient } from "@/lib/supabase/admin";
import { sha256 } from "@/lib/device-api";
import { raiseSimAlert } from "@/lib/sim-alert";

export async function POST(req: Request) {
  const b = await req.json().catch(() => null);
  if (!b) return Response.json({ success: false, error: "bad request" }, { status: 400 });
  const admin = createAdminClient();
  const { data: enr } = await admin.from("device_enrollments").select("id,shop_id,device_id,customer_id,agreement_id,device_token_hash").eq("id", b.device_id).maybeSingle();
  if (!enr || enr.device_token_hash !== sha256(b.device_token || "")) return Response.json({ success: false, error: "unauthorized" }, { status: 401 });
  const type = String(b.event_type ?? "unknown");
  const isSim = type.toLowerCase().includes("sim");
  if (isSim) {
    // SIM removed/changed: one open alert per phone + locked server-side until staff decide.
    await raiseSimAlert(admin, enr, type, b.details ?? null);
  } else {
    await admin.from("device_security_events").insert({
      shop_id: enr.shop_id, enrollment_id: enr.id, device_id: enr.device_id,
      event_type: type, details: b.details ?? null, status: "new",
    });
  }
  return Response.json({ success: true, data: null, message: "recorded" });
}
